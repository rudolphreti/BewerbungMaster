﻿namespace BewerbungMasterApp.Services
{
    public static partial class FileManagementServiceStatic
    {
    }
}
